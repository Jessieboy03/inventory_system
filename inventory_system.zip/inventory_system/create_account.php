<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ensure all required POST variables are set
    if (!isset($_POST['username'], $_POST['password'], $_POST['role'], $_POST['user_level'])) {
        die("All form fields are required.");
    }

    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = $_POST['role'];
    $user_level = $_POST['user_level'];  // Ensure this key exists

    // Database connection details
    $servername = "localhost";
    $db_username = "root";
    $db_password = "";  // Change if you have a password
    $dbname = "inventory_system";

    // Create connection
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the user_level exists in user_groups table
    $stmt = $conn->prepare("SELECT COUNT(*) FROM user_groups WHERE group_level = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("s", $user_level);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count == 0) {
        die("Error: user_level does not exist in user_groups table.");
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO users (username, password, role, user_level) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("ssss", $username, $password, $role, $user_level);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New account created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close connections
    $stmt->close();
    $conn->close();
}
?>
