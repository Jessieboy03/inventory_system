<?php
session_start();
if ($_SESSION['role'] !== 'inventory_manager') {
    header('Location: login.php');
    exit();
}

// Include the database configuration file
require 'db.php';

// Check if the connection was successfully created
if (!isset($conn)) {
    die("Database connection failed. Please check the db.php file.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Manager Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
</head>

<style>
/* (styles here) */
</style>

<body>
    <div class="container">
        <header>
            <h1>Inventory Management</h1>
            <a href='logout.php' class="logout-btn">Logout</a>
        </header>
        
        <nav>
            <ul>
                <li><button id="addProductBtn">Add Products</button></li>
                <li><a href="#viewInventory">View Inventory</a></li>
            </ul>
        </nav>

        <section id="addProductSection">
            <h2>Manage Inventory</h2>
            <div id="addProductModal" class="modal">
                <div class="modal-content">
                    <span class="close">&times;</span>
                    <form id="addProductForm" method="post" action="add_inventory.php">
                        <label for="name">Product Name:</label>
                        <input type="text" name="name" id="name" required><br>
                        
                        <label for="category">Category:</label>
                        <input type="text" name="category" id="category" required><br>

                        <label for="price">Price:</label>
                        <input type="number" step="0.01" name="price" id="price" required><br>
                        
                        <label for="quantity">Quantity:</label>
                        <input type="number" name="quantity" id="quantity" min="1" required><br>

                        <label for="barcode">Generate Barcode:</label>
                        <input type="text" name="barcode" id="barcode" required><br>
                        
                        <input type="submit" value="Add Product">
                    </form>
                </div>
            </div>
        </section>

        <section id="viewInventory">
            <h2>Inventory List</h2>
            <?php
            // Fetch inventory data
            $result = $conn->query("SELECT * FROM inventory_systems");

            if ($result->num_rows > 0) {
                echo "<table>";
                echo "<tr><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Quantity</th><th>Barcode</th><th>Actions</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['category'] . "</td>";
                    echo "<td>" . $row['price'] . "</td>";
                    echo "<td>" . $row['quantity'] . "</td>";
                    echo "<td>" . $row['barcode'] . "</td>";
                    echo "<td>";
                    echo "<a href='edit_inventory.php?id=" . $row['id'] . "'>Edit</a> | ";
                    echo "<a href='delete_inventory.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure?\")'>Delete</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No inventory items found.";
            }
            ?>
        </section>
    </div>
</body>
</html>
