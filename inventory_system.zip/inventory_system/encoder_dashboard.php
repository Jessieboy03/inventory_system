<?php
session_start();
if ($_SESSION['role'] !== 'encoder') {
    header('Location: login.php');
    exit();
}

echo "Welcome, Encoder!";
echo "<a href='logout.php'>Logout</a>";

// Handle customer data encoding and amortization
?>
<h2>Customer Data</h2>
<form method="post" action="add_customer.php">
    Customer Name: <input type="text" name="name"><br>
    Contact Info: <input type="text" name="contact_info"><br>
    <input type="submit" value="Add Customer">
</form>
