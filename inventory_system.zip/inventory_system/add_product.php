<?php
require 'vendor/autoload.php'; 
require 'config.php';

use Picqer\Barcode\BarcodeGeneratorHTML;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    // Generate a unique barcode
    $barcode = uniqid();

    // Insert product into the database
    $stmt = $pdo->prepare("INSERT INTO products (name, description, quantity, price, barcode) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $description, $quantity, $price, $barcode]);

    // Display the barcode
    $generator = new BarcodeGeneratorHTML();
    $barcodeHTML = $generator->getBarcode($barcode, $generator::TYPE_CODE_128);

    echo "<h2>Product Added Successfully!</h2>";
    echo "<p>Barcode:</p>";
    echo $barcodeHTML;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Add New Product</h1>
    <form method="post" action="add_product.php">
        <label for="name">Product Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea>
        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" required>
        <label for="price">Price:</label>
        <input type="number" step="0.01" id="price" name="price" required>
        <button type="submit">Add Product</button>
    </form>
</body>
</html>
