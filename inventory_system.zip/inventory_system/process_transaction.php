<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $barcode = $_POST['barcode'];
    $quantity = $_POST['quantity'];

    $stmt = $pdo->prepare("SELECT * FROM products WHERE barcode = ?");
    $stmt->execute([$barcode]);
    $product = $stmt->fetch();

    if ($product && $product['stock'] >= $quantity) {
        $total_price = $product['price'] * $quantity;
        $stmt = $pdo->prepare("INSERT INTO transactions (product_id, quantity, total_price, cashier_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$product['id'], $quantity, $total_price, $_SESSION['user_id']]);

        $stmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
        $stmt->execute([$quantity, $product['id']]);

        echo "Transaction successful!";
    } else {
        echo "Insufficient stock or invalid product!";
    }
}
?>
