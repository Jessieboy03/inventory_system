<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
         body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #ecf0f1;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            width: 250px;
            background: #34495e;
            color: white;
            height: 100vh;
            position: fixed;
            display: flex;
            flex-direction: column;
            align-items: center;
            transition: all 0.3s;
        }
        .sidebar .logo {
            width: 100px;
            height: 100px;
            margin: 20px 0;
            background: url('NHE.jpg') no-repeat center center;
            background-size: cover;
            border-radius: 50%;
        }
        .sidebar a {
            color: white;
            margin: 10px 30px;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            text-decoration: none;
            width: calc(100% - 60px);
            border-radius: 5px;
            transition: background 0.3s ease-in-out, padding-left 0.3s;
        }
        .sidebar a:hover {
            background: #2c3e50;
            padding-left: 40px;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            transition: all 0.3s;
        }
        .header {
            background-color: #34495e;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 5px;
        }
        .logout {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            background: #e74c3c;
            border-radius: 5px;
            transition: background 0.3s ease-in-out;
        }
        .logout:hover {
            background: #c0392b;
        }
        .content {
            display: none;
            background: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .content.active {
            display: block;
        }
        h2 {
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .icon {
            margin-right: 10px;
        }
        .user-management-options {
            display: none;
            flex-direction: column;
            align-items: flex-start;
            overflow: hidden;
            transition: max-height 0.3s ease-in-out;
        }
        .user-management:hover .user-management-options {
            display: flex;
            max-height: 500px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 15px;
            text-align: left;
        }
        th {
            background-color: #34495e;
            color: #34495e;
        }
        .action-buttons button {
            padding: 10px;
            margin: 0 5px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            color: white;
        }
        .action-buttons .update {
            background-color: #3498db;
        }
        .action-buttons .remove {
            background-color: #e74c3c;
        }
        .action-buttons .update:hover {
            background-color: #2980b9;
        }
        .action-buttons .remove:hover {
            background-color: #c0392b;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
        }

        .modal {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #ecf0f1;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            display: none;
        }
        .modal-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #ecf0f1;
        }

        .modal-content h2 {
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .modal-content label {
            display: block;
            margin-bottom: 10px;
            color: #2c3e50;
        }
        .modal-content input,
        .modal-content select,
        .modal-content button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 3px;
            box-sizing: border-box;
        }
        .modal-content button {
            background-color: #3498db;
            color: white;
            border: none;
            cursor: pointer;
        }
        .modal-content button:hover {
            background-color: #2980b9;
        }
        .close {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
        }
        #modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: none;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
    display: block;
    margin-bottom: 10px;
    }

    input, select {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
    }

    button[type="submit"] {
        background-color:  #34495e;
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button[type="submit"]:hover {
        background-color: #2980b9;
    }

    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo"></div>
        <a href="javascript:void(0);" data-target="dashboard"><i class="fas fa-tachometer-alt icon"></i> Dashboard</a>
        <a href="javascript:void(0);" class="user-management" data-target="manage-users">
            <i class="fas fa-users icon"></i> User Management
            <div class="user-management-options">
            <a href="javascript:void(0);" data-target="manage-users"><i class="fas fa-user-edit icon"></i> Manage Users</a>
            </div>
        </a>
        <a href="javascript:void(0);" data-target="generate-reports"><i class="fas fa-chart-line icon"></i> Generate Reports</a>
        <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>
    <div class="main-content">
        <div class="header">
            <h1>Welcome, Admin!</h1>
        </div>
        <div class="content" id="dashboard">
            <h2><i class="fas fa-tachometer-alt icon"></i> Dashboard</h2>
            <!-- Dashboard content here -->
        </div>
        <div class="content" id="manage-users">
            <h2><i class="fas fa-user-edit icon"></i> Manage Users</h2>
            <button onclick="openModal()">Add New User</button>
            <table>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="users-tbody">
                    <!-- Fetch and display users from the database here -->
                    
                </tbody>
            </table>
        </div>
        <div class="content" id="generate-reports">
            <h2><i class="fas fa-chart-line icon"></i> Generate Reports</h2>
            <!-- Report generation content here -->
        </div>
    </div>
   
    <!-- Add a div to overlay the entire page when the modal is open -->
    <div id="modal-overlay"></div>

    <div id="createAccountModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>Create Account</h2>
        <form id="createAccountForm" method="post" action="create_account.php">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="role">Role:</label>
                <select id="role" name="role" required>
                    <option value="admin">Admin</option>
                    <option value="cashier">Cashier</option>
                    <option value="inventory_manager">Inventory Manager</option>
                    <option value="encoder">Encoder</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Create Account</button>
        </form>
    </div>
</div>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            document.querySelectorAll('.sidebar a').forEach(link => {
                link.addEventListener('click', function () {
                    const target = this.getAttribute('data-target');
                    showContent(target);
                });
            });

            // Fetch users on load
            fetchUsers();
        });

        function showContent(id) {
            var contents = document.getElementsByClassName('content');
            for (var i = 0; i < contents.length; i++) {
                contents[i].classList.remove('active');
            }
            document.getElementById(id).classList.add('active');
        }

       // Update the JavaScript code to handle modal functionality
        let modal = document.getElementById('createAccountModal');
        let modalOverlay = document.getElementById('modal-overlay');

        function openModal() {
            modal.style.display = 'block';
            modalOverlay.style.display = 'block';
            modalOverlay.addEventListener('click', closeModal);
        }

        function closeModal() {
            modal.style.display = 'none';
            modalOverlay.style.display = 'none';
            modalOverlay.removeEventListener('click', closeModal);
        }

// Add an event listener to the "Add New User" button
document.getElementById('add-new-user-button').addEventListener('click', openModal);
        function fetchUsers() {
            // Example function to fetch users from a database (replace with actual database fetching code)
            // Here, we use a static example
            const users = [
                { username: 'admin', role: 'admin' },
                { username: 'cashier1', role: 'cashier' },
                { username: 'inventory_manager1', role: 'inventory_manager' },
                { username: 'encoder1', role: 'encoder' },
            ];

            const usersTableBody = document.getElementById('users-tbody');
            usersTableBody.innerHTML = '';

            users.forEach(user => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${user.username}</td>
                    <td>${user.role}</td>
                    <td>
                        <button onclick="editUser('${user.username}')">Edit</button>
                        <button onclick="deleteUser('${user.username}')">Delete</button>
                    </td>
                `;
                usersTableBody.appendChild(tr);
            });
        }

        function editUser(username) {
            // Implement function to edit user (replace with actual code)
            alert(`Edit user with username '${username}'`);
        }

        function deleteUser(username) {
            // Implement function to delete user (replace with actual code)
            if (confirm(`Are you sure you want to delete user with username '${username}'?`)) {
                alert(`User with username '${username}' deleted.`);
            }
        }
    </script>

</body>
</html>

<!-- You can also include CSS file in the head tag -->
<link rel="stylesheet" href="styles.css">

<!-- Note: This is a basic example. For a more realistic and secure implementation, consider using PHP and MySQL to handle user authentication and data management. -->