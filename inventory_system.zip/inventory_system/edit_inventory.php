<?php
session_start();
if ($_SESSION['role'] !== 'inventory_manager') {
    header('Location: login.php');
    exit();
}

require 'db_connection.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM inventory WHERE id=$id");
    $product = $result->fetch_assoc();
} 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $category = $conn->real_escape_string($_POST['category']);
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $barcode = $conn->real_escape_string($_POST['barcode']);

    if ($name && $category && $price > 0 && $quantity > 0 && $barcode) {
        $sql = "UPDATE inventory SET name='$name', category='$category', price=$price, quantity=$quantity, barcode='$barcode' WHERE id=$id";
        if ($conn->query($sql) === TRUE) {
            header('Location: inventory_dashboard.php');
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Invalid input.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Inventory Item</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Edit Inventory Item</h1>
            <a href='logout.php' class="logout-btn">Logout</a>
        </header>
        
        <section>
            <form method="post" action="edit_inventory.php">
                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                <label for="name">Product Name:</label>
                <input type="text" name="name" id="name" value="<?php echo $product['name']; ?>" required><br>
                
                <label for="category">Category:</label>
                <input type="text" name="category" id="category" value="<?php echo $product['category']; ?>" required><br>

                <label for="price">Price:</label>
                <input type="number" step="0.01" name="price" id="price" value="<?php echo $product['price']; ?>" required><br>
                
                <label for="quantity">Quantity:</label>
                <input type="number" name="quantity" id="quantity" value="<?php echo $product['quantity']; ?>" min="1" required><br>

                <label for="barcode">Barcode:</label>
                <input type="text" name="barcode" id="barcode" value="<?php echo $product['barcode']; ?>" required><br>
                
                <input type="submit" value="Update Product">
            </form>
        </section>
    </div>
</body>
</html>
