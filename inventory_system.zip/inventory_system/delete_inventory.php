<?php
session_start();
if ($_SESSION['role'] !== 'inventory_manager') {
    header('Location: login.php');
    exit();
}

require 'db_connection.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "DELETE FROM inventory WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header('Location: inventory_dashboard.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
