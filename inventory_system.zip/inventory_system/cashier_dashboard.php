<?php
session_start();
if ($_SESSION['role'] !== 'cashier') {
    header('Location: login.php');
    exit();
}

echo "Welcome, Cashier!";
echo "<a href='logout.php'>Logout</a>";

// Handle barcode scanning and transaction processing
?>
<h2>Point of Sale</h2>
<form method="post" action="process_transaction.php">
    Scan Barcode: <input type="text" name="barcode"><br>
    Quantity: <input type="number" name="quantity" min="1" value="1"><br>
    <input type="submit" value="Process">
</form>
