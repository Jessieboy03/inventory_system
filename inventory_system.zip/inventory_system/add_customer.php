<?php
session_start();
include 'db.php';

if ($_SESSION['role'] !== 'encoder') {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $contact_info = $_POST['contact_info'];

    $stmt = $pdo->prepare("INSERT INTO customers (name, contact_info) VALUES (?, ?)");
    $stmt->execute([$name, $contact_info]);

    echo "Customer added successfully!";
}
?>
