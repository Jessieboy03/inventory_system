<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['barcode'])) {
    $barcode = $conn->real_escape_string($_GET['barcode']);
    $result = $conn->query("SELECT * FROM inventory WHERE barcode='$barcode'");

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
        echo "<h2>Product Details</h2>";
        echo "<p>ID: " . $product['id'] . "</p>";
        echo "<p>Name: " . $product['name'] . "</p>";
        echo "<p>Category: " . $product['category'] . "</p>";
        echo "<p>Price: $" . $product['price'] . "</p>";
        echo "<p>Quantity: " . $product['quantity'] . "</p>";
        echo "<p>Barcode: " . $product['barcode'] . "</p>";
    } else {
        echo "Product not found.";
    }
} else {
    echo "Invalid request.";
}
?>
