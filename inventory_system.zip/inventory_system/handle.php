<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nhemarketing";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// User details
$user = 'encoder';
$plainPassword = 'encoder';
$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);
$role = 'encoder';

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $user, $hashedPassword);

if ($stmt->execute()) {
    echo "New user created successfully";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
