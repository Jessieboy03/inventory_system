<?php
session_start();
include 'db.php';

// Generate CSRF token if not already done
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF token validation
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error = 'Invalid CSRF token';
    } else {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        if (empty($username) || empty($password)) {
            $error = 'Username and password are required';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                switch ($user['role']) {
                    case 'admin':
                        header('Location: admin_dashboard.php');
                        break;
                    case 'cashier':
                        header('Location: cashier_dashboard.php');
                        break;
                    case 'inventory_manager':
                        header('Location: inventory_dashboard.php');
                        break;
                    case 'encoder':
                        header('Location: encoder_dashboard.php');
                        break;
                }
                exit;
            } else {
                $error = 'Invalid login credentials';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<style>
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #ff4b4b, #4caf50, #1a237e); 
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.login-container {
    background-color: #ffffff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    width: 280px;
    text-align: center;
}

.login-container .logo {
    max-width: 100px;
    margin-bottom: 20px;
}

.login-container h2 {
    margin-bottom: 20px;
    color: #333333;
}

.form-group {
    margin-bottom: 20px;
    position: relative;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    color: #555555;
    font-weight: bold;
}

.form-group input[type="text"],
.form-group input[type="password"] {
    width: 100%;
    padding: 10px;
    padding-left: 40px;
    border: 1px solid #cccccc;
    border-radius: 5px;
    box-sizing: border-box;
}

.form-group input[type="submit"] {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 5px;
    background-color: #007bff;
    color: white;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.form-group input[type="submit"]:hover {
    background-color: #0056b3;
}

.error {
    color: red;
    margin-bottom: 15px;
    font-size: 14px;
}

.icon {
    position: relative;
}

.icon input {
    padding-left: 40px;
}

.icon .fa {
    position: absolute;
    left: 10px;
    top: 65%;
    transform: translateY(-50%);
    color: #cccccc;
}

</style>

<body>
    <div class="login-container">

        <img src="NHE.jpg" alt="Logo" class="logo">
        <form method="post" action="login.php">
            <?php if (!empty($error)) : ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <div class="form-group icon">
                <label for="username">Username:</label>
                <i class="fa fa-user"></i>
                <input type="text" name="username" id="username" required>
            </div>
            <div class="form-group icon">
                <label for="password">Password:</label>
                <i class="fa fa-lock"></i>
                <input type="password" name="password" id="password" required>
            </div>
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
            <div class="form-group">
                <input type="submit" value="Login">
            </div>
        </form>
    </div>
</body>
</html>