<?php
session_start();
if ($_SESSION['role'] !== 'inventory_manager') {
    header('Location: login.php');
    exit();
}

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $category = $conn->real_escape_string($_POST['category']);
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $barcode = $conn->real_escape_string($_POST['barcode']);

    if ($name && $category && $price > 0 && $quantity > 0 && $barcode) {
        $sql = "INSERT INTO inventory (name, category, price, quantity, barcode) VALUES ('$name', '$category', $price, $quantity, '$barcode')";
        if ($conn->query($sql) === TRUE) {
            header('Location: inventory_dashboard.php');
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Invalid input.";
    }
}
?>
